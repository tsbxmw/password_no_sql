---
layout: post
title: Android APP 登录 注册 SAE 部署 - [4] 客户端编写 - 登录 
categories: Android
description: 笔记
keywords: Android, login, SAE, Java, Web
---
Android APP 登录 注册 SAE 部署 - [4] 客户端编写 - 登录 

## 链接
* [pre](https://tsbxmw.github.io/2016/08/15/Android-app_test_3/)
* [next](https://tsbxmw.github.io/2016/08/25/Android-app_test_5/)

##  内容

## READ ME：    
      如果你需要一个自己使用的APP登录和注册的Android demo。
      使用的是JAVA Web发布APP需要的信息
      JAVA Web获取APP的请求信息后查询外部数据库Mysql，并返回结果。
      APP通过Http client获取发布的信息
      进行登录或者注册操作
      请往下看，不然出门右转

### 客户端的编写
* 使用androidstudio 创建一个新的应用，这就是最简单的客户端。
* 所有功能已完成见link
* 后面增加新的功能
* [登录](https://tsbxmw.github.io/2016/08/20/Android-app_test_4/)
* [注册](https://tsbxmw.github.io/2016/08/25/Android-app_test_5/)
* [记住密码](https://tsbxmw.github.io/2016/08/30/Android-app_test_6/)
* [自动登录](https://tsbxmw.github.io/2016/08/20/Android-app_test_7/)
* [动画显示](https://tsbxmw.github.io/2016/08/20/Android-app_test_8/)
* [好友添加](https://tsbxmw.github.io/2016/08/20/Android-app_test_9/)
* [好友列表](https://tsbxmw.github.io/2016/08/20/Android-app_test_10/)
* [日历显示](https://tsbxmw.github.io/2016/08/20/Android-app_test_11/)
* [Webview](https://tsbxmw.github.io/2016/08/20/Android-app_test_12/)
* [天气显示](https://tsbxmw.github.io/2016/08/20/Android-app_test_13/)
* [扫码功能](https://tsbxmw.github.io/2016/08/20/Android-app_test_14/)
* [生成二维码功能](https://tsbxmw.github.io/2016/08/20/Android-app_test_15/)
* 等

### 登录功能

    <不定期更新>

#### link

* [github - xxx1 project](https://github.com/tsbxmw/xxx1)



### NEXT -->Android APP 登录 注册 SAE 部署 - [5] 客户端编写 - 注册
* [next](https://tsbxmw.github.io/2016/08/25/Android-app_test_5/)